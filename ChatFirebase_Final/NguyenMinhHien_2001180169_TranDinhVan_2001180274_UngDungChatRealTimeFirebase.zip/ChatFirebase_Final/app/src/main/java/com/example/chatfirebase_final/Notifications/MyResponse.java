package com.example.chatfirebase_final.Notifications;

public class MyResponse {
    public int success;
}
